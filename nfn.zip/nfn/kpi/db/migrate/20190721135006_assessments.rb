class Assessments < ActiveRecord::Migration[5.2]
  def change
    create_table :assessments do |t|
      t.integer :tamil
      t.integer :english
      t.integer :maths
      t.integer :social
      t.integer :science
      t.integer :total
      t.string :tam
      t.string :eng
      t.string :mat
      t.string :sci
      t.string :soc

      t.timestamps
    end
  end
end
