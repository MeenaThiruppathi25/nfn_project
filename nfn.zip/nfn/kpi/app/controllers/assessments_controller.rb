class AssessmentsController < ApplicationController
  before_action :set_assessment, only: [:show]
  load_and_authorize_resource :only => [:index]

  def new
    @assessment = Assessment.new
  end

  def create
    @assessment = Assessment.new(assessments_params)
    if @assessment.save
      redirect_to assessment_path(@assessment), notice: "Your Assessment is submitted sucessfully"
    else
      render :new
    end
  end

  def show
  end

  def index
    @assessment = Assessment.all
  end

  private

  def set_assessment
    @assessment = Assessment.find(params[:id])
  end

  def assessments_params
    params.require(:assessment).permit(:tamil, :english, :maths, :science, :social, :tam, :eng, :mat, :sci, :soc)
  end
end
