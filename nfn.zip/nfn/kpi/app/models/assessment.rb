class Assessment < ActiveRecord::Base
  validates :tamil, presence: true
  validates :english, presence: true
  validates :maths, presence: true
  validates :science, presence: true
  validates :social, presence: true
end
