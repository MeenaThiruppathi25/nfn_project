# frozen_string_literal: true

class Ability
  include CanCan::Ability

  def initialize(user)
    if user.role?
      can :manage, :all
    else
      cannot [:index], AssessmentsController
    end
  end
end
