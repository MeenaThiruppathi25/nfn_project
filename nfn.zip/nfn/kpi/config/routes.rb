Rails.application.routes.draw do
  get 'dashboard/index'
  resources :dashboard
  resources :assessments do
    get 'assessments/new' => 'assessments#new'
    get 'assessments' => 'assessment#index'
  end
  
  devise_for :users, controllers: {sessions: 'users/sessions', passwords: 'users/passwords', registrations: 'users/registrations'}
  devise_scope :user do
    get '/users/sign_out' => 'devise/sessions#destroy'
    post '/users/sign_out' => 'devise/sessions#destroy'
    get '/sign_in' => 'devise/sessions#sign_in_partial'
  end
    root 'dashboard#index'
end
