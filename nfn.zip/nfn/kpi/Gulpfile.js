var gulp, sass, rename;

gulp = require('gulp');
sass = require('gulp-sass');
rename = require("gulp-rename");

gulp.task('default', ['scss-css']);

gulp.task('scss-css', function() {
    gulp.src('vendor/assets/stylesheets/style.scss')
        .pipe(sass({
            indentedSyntax: false,
            errLogToConsole: true,
            outputStyle: 'compressed'
        }))
        .pipe(rename({
            basename: 'base'
        }))
        .pipe(gulp.dest('vendor/assets/stylesheets'));
});
